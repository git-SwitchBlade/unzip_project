import requests
from bs4 import BeautifulSoup
import json



url = "https://en.wikipedia.org/wiki/Aston_Martin"

keywords = ["wiki", "wikipedia"]

# proxies = {'http': 'http://190.64.18.177:80'}
headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36'
}

visited = set()

def banner():
    print(r"""
        ##      ## ######## ########   ######   ######  ########     ###    ########  ######## ########  
        ##  ##  ## ##       ##     ## ##    ## ##    ## ##     ##   ## ##   ##     ## ##       ##     ## 
        ##  ##  ## ##       ##     ## ##       ##       ##     ##  ##   ##  ##     ## ##       ##     ## 
        ##  ##  ## ######   ########   ######  ##       ########  ##     ## ########  ######   ########  
        ##  ##  ## ##       ##     ##       ## ##       ##   ##   ######### ##        ##       ##   ##   
        ##  ##  ## ##       ##     ## ##    ## ##    ## ##    ##  ##     ## ##        ##       ##    ##  
         ###  ###  ######## ########   ######   ######  ##     ## ##     ## ##        ######## ##     ##  
          """)

def get_links(url, depth):
    if depth == 0 or url in visited:
        return []

    visited.add(url)
    links = []
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')
        for a in soup.find_all('a', href=True, limit=100):
            link = a['href']
            if link.startswith("http"):  # To get absolute URLs
                links.append(link)
                links.extend(get_links(link, depth-1))
    except requests.RequestException as e:
        print(f"Error fetching URL: {url}. Error: {e}")
    
    return links

def save_to_json(data, filename="web/links.json"):
    print(len(data))
    set(data)
    with open(filename, 'w') as f:
        json.dump(data, f, indent=4)
    searchKeyword()

def searchKeyword():
    keywordLinks = []
    with open("web/links.json", "r") as r:
        data = json.load(r)
    for keyword in keywords:
        for link in data:
            if keyword in link:
                keywordLinks.append(link)
    nonDuplicateLink = list(set(keywordLinks))
    with open("web/keywordLinks.json", "w") as file:
        json.dump(nonDuplicateLink, file, indent=4)



def webMain():
    depth = 2  # Adjust depth as needed. Depth 2 means it'll get links from the starting URL and then links from those links.
    banner()
    links = get_links(url, depth)
    unique_links = list(set(links))  # Removing duplicates
    save_to_json(unique_links)
    print("[+] Results are stored in /web")