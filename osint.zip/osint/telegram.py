from telethon.sync import TelegramClient
from telethon import functions
from telethon.tl.functions.messages import GetHistoryRequest
import json
from datetime import date
from datetime import datetime

api_id = 24616000
api_hash = 'd8f840b9259e8222d8e4e9c613aaab92'
link = 'https://t.me/thebugbountyhunter'

keywords = ["CVE"]
FoundKeywords = []

client = TelegramClient('anon', api_id, api_hash)

def banner():
    print(r"""
        ######## ######## ##       ########  ######   ########     ###    ##     ## 
           ##    ##       ##       ##       ##    ##  ##     ##   ## ##   ###   ### 
           ##    ##       ##       ##       ##        ##     ##  ##   ##  #### #### 
           ##    ######   ##       ######   ##   #### ########  ##     ## ## ### ## 
           ##    ##       ##       ##       ##    ##  ##   ##   ######### ##     ## 
           ##    ##       ##       ##       ##    ##  ##    ##  ##     ## ##     ## 
           ##    ######## ######## ########  ######   ##     ## ##     ## ##     ##
    """)


def json_serial(obj):
    """JSON serializer for objects not serializable by default json code"""

    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    raise TypeError ("Type %s not serializable" % type(obj))



def searchKeyword():
    with open("telegram/telegram_messages.json", "r") as r:
        searchData = json.load(r)
    for keyword in keywords:
        for data in searchData:
            if keyword in data["message"]:
                FoundKeywords.append(data)
    with open("telegram/FoundKeywordsTelegram.json", "w") as file:
        json.dump(FoundKeywords, file, indent=4)
                
    

        
async def fetch():
        await client.start()
        await client(functions.channels.JoinChannelRequest(link))
        
        offset_id = 0
        limit = 100
        all_messages = []
        total_messages = 0 
        total_count_limit = 1000 #Note : if total_count_limit = 0 means fetching all messages in a group that could take tons of time. 
        my_channel = await client.get_entity(link)

        while True:
            print("Current Offset ID is:", offset_id, "; Total Messages:", total_messages)
            history = await client(GetHistoryRequest(
                peer=my_channel,
                offset_id=offset_id,
                offset_date=None,
                add_offset=0,
                limit=limit,
                max_id=0,
                min_id=0,
                hash=0
            ))
            if not history.messages:
                break
            messages = history.messages
            for message in messages:
                all_messages.append(message.to_dict())
            offset_id = history.messages[-1].id
            total_messages = len(all_messages)
            if total_count_limit != 0 and total_messages >= total_count_limit:
                break
                      
        print(f"Retrieved {len(all_messages)} messages so far...")
        
        new_messages = [{'id': message['id'], 'message': message['message'], 'date': message['date']} for message in all_messages]
        with open("telegram/telegram_messages.json", "w", encoding="utf-8") as w:
            json.dump(new_messages, w, indent=4, default=json_serial)
        
        searchKeyword()


def telegramMain():
    banner()     
    with client:
        client.loop.run_until_complete(fetch())

    print("[+] Results are stored in /telegram")