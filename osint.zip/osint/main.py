from telegram import telegramMain
from discord_scrapper import discordMain
from webb import webMain
import os
import argparse

class color:
    blue = '\033[94m'
    green = '\033[92m'
    red = '\033[93m'
    underline = '\033[4m'
    reset = '\033[0m'

def main():
    parser = argparse.ArgumentParser(description="Execute commands from different files.")
    parser.add_argument('--d', action='store_true', help='Execute command from file1')
    parser.add_argument('--t', action='store_true', help='Execute command from file2')
    parser.add_argument('--w', action='store_true', help='Execute command from file3')
    args = parser.parse_args()

    os.system('cls')

    if args.d:
        print(f"{color.blue} [+] Running Discord Scraper")
        discordMain()
        print(f"{color.reset}")
    if args.t:
        print(f"{color.green} [+] Running Telegram Scraper")
        telegramMain()
        print(f"{color.reset}")
    if args.w:
        print(f"{color.red} [+] Running Web Link Scraper")
        webMain()
        print(f"{color.reset}")

if __name__=='__main__':
    main()

