import requests
from bs4 import BeautifulSoup
import yaml
import random

url = "https://en.wikipedia.org/wiki/Aston_Martin"
# headers = {"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36"}

proxies = {'http': 'http://190.64.18.177:80'} 
response = requests.get(url, proxies=proxies)
soup = BeautifulSoup(response.content, 'html.parser')

def generateRandomFileName():
    uppr = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    lower = uppr.lower()
    num = "0123456789"
    lengthOfFileName = 6
    op_strings = uppr + lower + num 

    randomFileName = "".join(random.sample(op_strings, lengthOfFileName))
    return randomFileName


def linkTree():
    

    with open("link_con.yaml", "r") as r:
        yamlData = yaml.safe_load(r)
        for domain in yamlData['href']:
            res = requests.get(domain)
            link_soup = BeautifulSoup(res.content, 'html.parser')
            body_content = {
                    "title": "body ",
                    "paragraphs": [p.get_text() for p in link_soup.find_all('p', limit=30)]
            }
            yaml_body = yaml.dump(body_content, default_flow_style=False)
            with open(generateRandomFileName()+'.yaml', "w") as w:
                w.write(yaml_body)
            
            


def linkDump():
    link_content = {
        "title": "links",
        "href": [a['href'] for a in soup.find_all('a', href=True) if 'http' in a['href']]
    }

    yaml_content = yaml.dump(link_content, default_flow_style=False)

    with open("link_con.yaml", 'w') as file:
        file.write(yaml_content)
    linkTree()



if __name__=='__main__':
    linkDump()


