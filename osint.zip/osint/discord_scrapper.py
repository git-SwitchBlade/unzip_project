import requests
import json


headers = {
    "Authorization": "Enter your Authorization token",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36"
}

keywords = ["pls"]

def banner():
    print(r"""
        ########  ####  ######   ######   #######  ########  ########  
        ##     ##  ##  ##    ## ##    ## ##     ## ##     ## ##     ## 
        ##     ##  ##  ##       ##       ##     ## ##     ## ##     ## 
        ##     ##  ##   ######  ##       ##     ## ########  ##     ## 
        ##     ##  ##        ## ##       ##     ## ##   ##   ##     ## 
        ##     ##  ##  ##    ## ##    ## ##     ## ##    ##  ##     ## 
        ########  ####  ######   ######   #######  ##     ## ########  
    """)


def searchKeyword():
    with open("discord/discord.json", "r") as r:
        data = json.load(r)
    
    matches = []
    keyword = "pls"
    for channel, messages in data.items():
        if isinstance(messages, list):
            for msg in messages:
                if keyword in msg:
                    matches.append((channel, msg))

    with open("discord/FoundDiscordKeywords.json", "w") as w:
        json.dump(matches, w, indent=4)




def getGuildId(targetGuildName):
    url = "https://discord.com/api/v10/users/@me/guilds"


    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        guilds = response.json()
        for guild in guilds:
            if guild['name'] == targetGuildName:
                print("[+] Collecting Guild ID")
                return guild['id']
    else:
        print("[-] Failed to fetch GUILD ID")

def getGuildChannels(guild_id):
    url = f"https://discord.com/api/v10/guilds/{guild_id}/channels"
    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        print("[+] Collecting Channel IDs")
        return response.json()
    else:
        print("[-] requestt rejected for retreiving channel ids")

def scrapeTextChannels(channelID):
    params = {"limit": 100}
    url = f"https://discord.com/api/v10/channels/{channelID}/messages"
    response = requests.get(url, headers=headers, params=params)
    if response.status_code == 200:
        print("[+] Retreving message from channels")
        return [item['content'] for item in response.json()]
    else:
        print("[+] User Not Authorized for the channel")




def discordMain():
    banner()
    guild_id = getGuildId('tapri')
    channels = getGuildChannels(guild_id)
    channelMsg = {}

    for channel in channels:
        if channel['type'] == 0:
            channelName = channel['name']
            messages = scrapeTextChannels(channel['id'])
            channelMsg[channelName] = messages

    with open("discord/discord.json", "w") as w:
        json.dump(channelMsg, w, indent=4)

    searchKeyword()
    print("[+] Results are stored in /discord")